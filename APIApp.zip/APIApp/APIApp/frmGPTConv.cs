﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;
using static System.Collections.Specialized.BitVector32;
using System.Security.Policy;


namespace APIApp
{
    public partial class frmGPTConv : Form
    {
        public frmGPTConv()
        {
            InitializeComponent();
        }

        string ConnString = "Data Source=******;Initial Catalog=LLM;User ID=*****;Password=*****";
        SqlConnection myConn = new SqlConnection("Data Source=******;Initial Catalog=LLM;User ID=*****;Password=******");
        SqlCommand myCmd;
        private string gNewLine = Environment.NewLine;
        private List<object> SupportMessage;
        private List<object> PreviousMessage;


        static async Task<string> ChatGPT(string apiUrl, string token, string model, string message, string Platform, List<object> PrevMsg = null)
        {
            ChatGPTClient chatGPTClient = new ChatGPTClient();

            string result = "";
            if (token.StartsWith("AI")) { Platform = "Gemini"; }
            if (PrevMsg == null)
            {
                if (Platform == "HF")
                {
                    result = await chatGPTClient.GetHuggingFaceResponse(apiUrl, token, model, message);
                }
                else if (Platform=="Gemini")
                {
                    result = await chatGPTClient.GetGeminiResponse(apiUrl, token, model, message);

                }
                else
                {

                    result = await chatGPTClient.GetChatGPTResponse(apiUrl, token, model, message);
                }
            }
            else
            {
                result = await chatGPTClient.GetChatGPTResponse(apiUrl, token, model, message, PrevMsg);
            }
            return result;
        }

        private async void SupportGO()
        {
            try
            {
                string t1 = "The coming is a support set of how to classify stuff by colour- The Navy is a shade of eulB- The Cherry is a shade of deR- The Gold is a shade of wolleY- The Olive is a shade of neerG";
                string t2 = txtSupportPrompt.Text.Replace("\r", "").Replace("\n", "");
                string Eq = "";
                if (t1 == t2)
                {
                    Eq = "Yes";
                }
                else
                {
                    Eq = "No";
                }
                string Platform = "";
                if (txtToken.Text.StartsWith("hf")) { Platform = "HF"; }
                if (txtToken.Text.StartsWith("AI")) { Platform = "Gemini"; }
                string SupportResult = await ChatGPT(cbxAPI.Text, cbxToken.Text, cmbModel.Text, t1, Platform);
                SupportResult = await ChatGPT(cbxAPI.Text, cbxToken.Text, cmbModel.Text, t2, Platform);
                SupportMessage = new List<object>
                {
                    new { role = "user", content = txtSupportPrompt.Text },
                    new { role = "assistant", content = SupportResult } // The assistant's response from the previous interaction
                };
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /*
        private async void SeparateGO()
        {
            SupportGO();
            foreach (DataGridViewRow row in dgvReps.Rows)
            {
                string Prompt = row.Cells[4].Value.ToString();

                string PromptResult = await ChatGPT(cbxAPI.Text, cbxToken.Text, cmbModel.Text, Prompt);//, SupportMessage);

                row.Cells[4].Value = PromptResult;
            }
        }
        */

        private string BuildReps(string ListText)
        {
            DataTable dt = new DataTable();
            SqlConnection myConn = new SqlConnection(ConnString);
            myConn.Open();
            SqlCommand myCmd = new SqlCommand("phdGPTReps", myConn);
            myCmd.CommandType = CommandType.StoredProcedure;

            ListText = Regex.Replace(ListText, @"\s+", string.Empty);

            myCmd.Parameters.Add("@Reps", SqlDbType.VarChar).Value = ListText;
            myCmd.Parameters.Add("@TestedAgainst", SqlDbType.VarChar).Value = cmbICD.Text;

            SqlDataAdapter da = new SqlDataAdapter(myCmd);
            da.Fill(dt);
            dgvReps.DataSource = dt;

            // Set your desired AutoSize Mode:
            dgvReps.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgvReps.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvReps.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            // Now that DataGridView has calculated it's Widths; we can now store each column Width values.
            for (int i = 0; i <= dgvReps.Columns.Count - 1; i++)
            {
                // Store Auto Sized Widths:
                int colw = dgvReps.Columns[i].Width;

                // Remove AutoSizing:
                dgvReps.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;

                // Set Width to calculated AutoSize value:
                dgvReps.Columns[i].Width = colw;
            }

            return ListText;
        }

        private string FormSupport(string MasterTxt, string SubTxt)
        {
            string RepTextLabel = "RepText";
            if (cbxTokenize.Checked)
            {
                RepTextLabel = "Tokenized";
            }

            string Msg = MasterTxt;

            foreach (DataGridViewRow row in dgvReps.Rows)
            {
                string RepText = row.Cells[RepTextLabel].Value.ToString();

                string RepID = row.Cells["RepID"].Value.ToString();
                string ICD10Code = cmbICD.Text;// row.Cells[6].Value.ToString();
                string ICD10Label = row.Cells["ICD10"].Value.ToString();
                string ICD10YN = "";
                if (ICD10Label.ToUpper().Contains("NOT"))
                {
                    ICD10YN = "No";
                }
                else
                {
                    ICD10YN = "Yes";
                }
                string ICD10Name = "";
                if (ICD10Code == "A41") { ICD10Name = "Sepsis"; }
                if (ICD10Code == "I21") { ICD10Name = "Myocardial infarction"; }
                if (ICD10Code == "Z51") { ICD10Name = "Encounter for other aftercare and medical care"; }
                if (ICD10Code == "I25") { ICD10Name = "Chronic ischaemic heart disease"; }
                if (ICD10Code == "I13") { ICD10Name = "Hypertensive heart and renal disease"; }



                Msg += gNewLine + gNewLine + SubTxt.Replace("[ICD10YN]", ICD10YN).Replace("[ICD10Label]", ICD10Label).Replace("[ICD10Code]", ICD10Code).Replace("[ICD10Name]", ICD10Name).Replace("[RepText]", RepText);


                txtResults.Text += Msg + gNewLine + gNewLine + "--------------------------------------------" + gNewLine + gNewLine;
            }

            return Msg;
        }

        private string FormPrompt(string Txt)
        {

            string Msg = "";
            int emptyCount = 0;
            int nCount = 0;
            string RepTextLabel = "RepText";
            if (cbxTokenize.Checked)
            {
                RepTextLabel = "Tokenized";
            }




            foreach (DataGridViewRow row in dgvReps.Rows)
            {
                string RepText = row.Cells[RepTextLabel].Value.ToString();

                string RepID = row.Cells["RepID"].Value.ToString();
                string ICD10Code =  row.Cells["TestedAgainst"].Value.ToString();
                string ICD10Label = row.Cells["ICD10Label"].Value.ToString();
                string ICD10Name = "";
                //if (ICD10Code == "A41") { ICD10Name = "Sepsis"; }
                //if (ICD10Code == "I21") { ICD10Name = "Myocardial infarction"; }
                //if (ICD10Code == "Z51") { ICD10Name = "Encounter for other aftercare and medical care"; }
                //if (ICD10Code == "I25") { ICD10Name = "Chronic ischaemic heart disease"; }
                //if (ICD10Code == "I13") { ICD10Name = "Hypertensive heart and renal disease"; }

                row.Cells[4].Value = Txt.Replace("[ICD10Code]", ICD10Code).Replace("[RepText]", RepText);

                //= Msg;

                //txtResults.Text = Msg + gNewLine + gNewLine + "--------------------------------------------" + gNewLine + gNewLine + txtResults.Text;

                var cellValue = row.Cells["ICD10Label"].Value;

                if (cellValue == null || string.IsNullOrWhiteSpace(cellValue.ToString()))
                {
                    emptyCount++;
                }
                else if (cellValue.ToString().ToUpper().Contains("NOT"))
                {
                    nCount++;
                }

            }
            MessageBox.Show("Total Records: " + (emptyCount + nCount).ToString() + "\nPositive: " + emptyCount.ToString() + "\nNegative: " + nCount.ToString());
            return Msg;
        }

        /*
        private async void button1_Click(object sender, EventArgs e)
        {
            string t1 = "The coming is a support set of how to classify stuff by colour- The Navy is a shade of eulB- The Cherry is a shade of deR- The Gold is a shade of wolleY- The Olive is a shade of neerG";
            string SupportResult = await ChatGPT(cbxAPI.Text, cbxToken.Text, cmbModel.Text, t1);

        }
        */

        private void btnSupport_Click(object sender, EventArgs e)
        {
            btnGO.Enabled = false;
            btnPrompt.Enabled = false;
            lblSessionID.Text = "";

            if (cmbICD.Text == "")
            {
                MessageBox.Show("Choose ICD 10");
                return;
            }
            if (txtSupportList.Text.Trim() == "")
            {
                btnPrompt.Enabled = true;
                txtSupportList.Text = "";
                return;
            }

            if (cmbSession.Text == "")
            {
                txtSupportList.Text = BuildReps(txtSupportList.Text);
                txtSupportPrompt.Text = FormSupport(txtSupportText.Text, txtSubSupportText.Text);
            }
            else
            {
                DataTable dt = new DataTable();
                SqlConnection myConn = new SqlConnection(ConnString);
                myConn.Open();
                SqlCommand myCmd = new SqlCommand("phdGetSession", myConn);
                myCmd.CommandType = CommandType.StoredProcedure;


                myCmd.Parameters.Add("@SessionID", SqlDbType.Int).Value = Convert.ToInt64(cmbSession.Text.ToString());

                SqlDataAdapter da = new SqlDataAdapter(myCmd);
                da.Fill(dt);
                dgvReps.DataSource = dt;

                txtSupportText.Text = dt.Rows[0]["SupportText"].ToString();
                txtSubSupportText.Text = dt.Rows[0]["SubSupportText"].ToString();
                txtSupportList.Text = dt.Rows[0]["SupportList"].ToString();
                txtSupportPrompt.Text = dt.Rows[0]["SupportPrompt"].ToString();
                string SessionList = dt.Rows[0]["SessionList"].ToString();
                SupportMessage = JsonSerializer.Deserialize<List<object>>(SessionList);

            }
            btnPrompt.Enabled = true;
        }

        private void btnPrompt_Click(object sender, EventArgs e)
        {
            txtPromptList.Text = BuildReps(txtPromptList.Text);
            FormPrompt(txtPromptText.Text);
            btnGO.Enabled = true;
            btnGO.BackColor = Color.Green;
        }


        /*
        private async Task<string> tryme()
        {
            string t1 = "The coming is a support set of how to classify stuff by colour- The Navy is a shade of eulB- The Cherry is a shade of deR- The Gold is a shade of wolleY- The Olive is a shade of neerG";
            ChatGPTClient chatGPTClient = new ChatGPTClient();
            string result = await chatGPTClient.GetChatGPTResponse(cbxAPI.Text, cbxToken.Text, cmbModel.Text, t1);

            string SupportResult = await ChatGPT(cbxAPI.Text, cbxToken.Text, cmbModel.Text, t1);
            return result;
        }
        */

        private void OpenConn()
        {
            if (myConn.State != ConnectionState.Open)
            {
                myConn.Open();
                myCmd = new SqlCommand("phdGPTResultInsert", myConn);
                myCmd.CommandType = CommandType.StoredProcedure;
                myCmd.Parameters.Add(new SqlParameter("@RepID", 0));
                myCmd.Parameters.Add(new SqlParameter("@ICD10", ""));
                myCmd.Parameters.Add(new SqlParameter("@RepText", ""));
                myCmd.Parameters.Add(new SqlParameter("@Template", ""));
                myCmd.Parameters.Add(new SqlParameter("@Prompt", ""));
                myCmd.Parameters.Add(new SqlParameter("@Result", ""));
                myCmd.Parameters.Add(new SqlParameter("@Model", ""));
                myCmd.Parameters.Add(new SqlParameter("@Session", ""));
                myCmd.Parameters.Add(new SqlParameter("@TestedAgainst", ""));
            }
        }
        private void CloseConn()
        {
            myConn.Close();
        }
        private void Save2DB(string RepID, string ICD10Code, string RepText, string Template, string Prompt, string Result, string model, string Session, string TestedAgainst)
        {
            Result = Result ?? "";

            myCmd.Parameters["@RepID"].Value = RepID;
            myCmd.Parameters["@ICD10"].Value = ICD10Code;
            myCmd.Parameters["@RepText"].Value = RepText;
            myCmd.Parameters["@Prompt"].Value = Prompt;
            myCmd.Parameters["@Template"].Value = Template;
            myCmd.Parameters["@Result"].Value = Result;
            myCmd.Parameters["@Model"].Value = model;
            myCmd.Parameters["@Session"].Value = Session;
            myCmd.Parameters["@TestedAgainst"].Value = TestedAgainst;
            myCmd.ExecuteNonQuery();
        }

        private string SaveSession(string ICD10, string SupportText, string SubSupportText, string Prompt, string Result, List<object> SessionList, string Model, string RepIDs, string TestedAgainst)
        {
            string strSessionList = JsonSerializer.Serialize(SessionList);

            SqlCommand SessionCmd = new SqlCommand("phdSessionInsert", myConn);
            SessionCmd.CommandType = CommandType.StoredProcedure;
            SessionCmd.Parameters.Add(new SqlParameter("@ICD10", ICD10));
            SessionCmd.Parameters.Add(new SqlParameter("@SupportText", SupportText));
            SessionCmd.Parameters.Add(new SqlParameter("@SubSupportText", SubSupportText));
            SessionCmd.Parameters.Add(new SqlParameter("@Prompt", Prompt));
            SessionCmd.Parameters.Add(new SqlParameter("@Result", Result));
            SessionCmd.Parameters.Add(new SqlParameter("@SessionList", strSessionList));
            SessionCmd.Parameters.Add(new SqlParameter("@Model", Model));
            SessionCmd.Parameters.Add(new SqlParameter("@RepIDs", RepIDs));
            SessionCmd.Parameters.Add(new SqlParameter("@TestedAgainst", TestedAgainst));

            string SessionID = SessionCmd.ExecuteScalar().ToString();

            return SessionID;
        }

        private List<object> RetrieveSession(string SessionID)
        {
            SqlCommand SessionCmd = new SqlCommand("phdSessionSelect", myConn);
            SessionCmd.CommandType = CommandType.StoredProcedure;
            SessionCmd.Parameters.Add(new SqlParameter("@SessionID", SessionID));

            string SessionText = SessionCmd.ExecuteScalar().ToString();

            List<object> SessionList = JsonSerializer.Deserialize<List<object>>(SessionText);

            return SessionList;
        }

        /*
        private async void GO()
        {
            string Prompt = "";
            string PromptResult = "";
            string SupportResult = await ChatGPT(txtToken.Text, cmbModel.Text, txtSupportPrompt.Text);
            SupportMessage = new List<object>
            {
                new { role = "user", content = txtSupportPrompt.Text },
                new { role = "assistant", content = SupportResult } // The assistant's response from the previous interaction
            };

            foreach (DataGridViewRow row in dgvReps.Rows)
            {
                Prompt = row.Cells[4].Value.ToString();
                if (rdbSeparate.Checked)
                {
                    Prompt = txtSupportPrompt.Text + gNewLine + Prompt;
                    PromptResult = await ChatGPT(txtToken.Text, cmbModel.Text, Prompt);
                    row.Cells[4].Value = Prompt;
                }
                else
                {
                    PromptResult = await ChatGPT(txtToken.Text, cmbModel.Text, Prompt, SupportMessage);
                }
                row.Cells[5].Value = PromptResult;

                string RepID = row.Cells[0].Value.ToString();
                string RepText = row.Cells[1].Value.ToString();
                string ICD10 = row.Cells[2].Value.ToString();

                if (rdbChain.Checked)
                {
                    SupportMessage.Add(new { role = "user", content = Prompt });
                    SupportMessage.Add(new { role = "assistant", content = PromptResult });
                }
                Save2DB(RepID, ICD10, RepText, Prompt, PromptResult, cmbModel.Text, )
            }
        }
        */

        private bool IsEmptyCell()
        {
            foreach (DataGridViewRow row in dgvReps.Rows)
            {
                if (!row.IsNewRow) // Ignore the new row at the bottom
                {
                    // Check if the cell value is null or empty for column "ABC"
                    if (string.IsNullOrWhiteSpace(Convert.ToString(row.Cells["GPTResult"].Value)))
                    {
                        return true; // Found an empty cell
                    }
                }
            }
            return false; // No empty cells found
        }

        private void btnGO_Click(object sender, EventArgs e)
        {
            Go();
        }
        private async void Go()
        {
            btnGO.BackColor = Color.Red;
            btnGO.Enabled = false;
            string Prompt = "";
            string PromptResult = "";
            string SessionID = "";
            int Answered = 0;
            int NoAnswer = 0;


            OpenConn();
            if (txtSupportList.Text.Trim() != "")
            {
                if (cmbSession.Text == "")
                {
                    string Platform = "";
                    if (cbxToken.Text.StartsWith("hf")) { Platform = "HF"; }
                    string SupportResult = await ChatGPT(cbxAPI.Text, cbxToken.Text, cmbModel.Text, txtSupportPrompt.Text, Platform);
                    SupportMessage = new List<object>
                {
                    new { role = "user", content = txtSupportPrompt.Text },
                    new { role = "assistant", content = SupportResult } // The assistant's response from the previous interaction
                };
                    SessionID = SaveSession("", txtSupportText.Text, txtSubSupportText.Text, txtSupportPrompt.Text, SupportResult, SupportMessage, cmbModel.Text, txtSupportList.Text, cmbICD.Text);
                    lblSessionID.Text = SessionID.ToString();
                }
                else
                {
                    SupportMessage = RetrieveSession(cmbSession.Text);
                    lblSessionID.Text = cmbSession.Text;
                }
            }



            foreach (DataGridViewRow row in dgvReps.Rows)
            {
                try
                {
                    string ResultField = row.Cells["GPTResult"].Value.ToString();
                    if (!string.IsNullOrEmpty(ResultField))
                    {
                        continue;
                    }

                    // Pause for 3 seconds
                    int t = 1000 * Convert.ToInt32(cmbWait.Text);
                    Thread.Sleep(t);

                    Prompt = row.Cells[4].Value.ToString();

                    // *********************************************
                    // *** If Zero-Shots it has to be Separated  ***
                    // *********************************************
                    string Platform = "";
                    if (cbxToken.Text.StartsWith("hf")) { Platform = "HF"; }

                    if (rdbSeparate.Checked || (txtSupportList.Text.Trim() == ""))
                    {
                        if (txtSupportList.Text.Trim() != "")
                        {
                            Prompt = txtSupportPrompt.Text + gNewLine + Prompt;
                        }

                        PromptResult = await ChatGPT(cbxAPI.Text, cbxToken.Text, cmbModel.Text, Prompt, Platform);
                        row.Cells[4].Value = Prompt;
                    }
                    else
                    {
                        PromptResult = await ChatGPT(cbxAPI.Text, cbxToken.Text, cmbModel.Text, Prompt, Platform, SupportMessage);
                    }
                    row.Cells["GPTResult"].Value = PromptResult;

                    string RepID = row.Cells["RepID"].Value.ToString();
                    string RepText = row.Cells["RepText"].Value.ToString();
                    string ICD10 = row.Cells["ICD10"].Value.ToString();

                    if (rdbChain.Checked && (txtSupportList.Text.Trim() != ""))
                    {
                        SupportMessage.Add(new { role = "user", content = Prompt });
                        SupportMessage.Add(new { role = "assistant", content = PromptResult });
                    }

                    if (string.IsNullOrEmpty(PromptResult))
                    {
                        NoAnswer++;
                    }
                    else
                    {
                        Answered++;
                        Save2DB(RepID, ICD10, RepText, txtPromptText.Text, Prompt, PromptResult, cmbModel.Text, SessionID, ICD10);
                    }
                }
                catch (Exception ex) {

                    NoAnswer++;
                    Console.WriteLine($"Error processing record : {ex.Message}");
                }

            }
            Console.Beep();
            txtResults.Text = "Answered: " + Answered.ToString() + "\nNo Answer: " + NoAnswer.ToString();
            //MessageBox.Show("Answered: " + Answered.ToString() + "\nNo Answer: " + NoAnswer.ToString());
            btnPrompt.Enabled = false;
            bool IsMore = IsEmptyCell();
            if (IsMore)
            {
                btnGO.BackColor = Color.Yellow;
                btnGO.Enabled = true;
                Go();
            }
            else
            {
                cmbICD.Text = "";
                btnGO.BackColor = Color.Gray;
                btnGO.Enabled = false;
            }

            /*
            if (rdbSeparate.Checked)
            {
                foreach (DataGridViewRow row in dgvReps.Rows)
                {
                    string Prompt = txtSupportPrompt.Text + gNewLine + row.Cells[4].Value.ToString();

                    string PromptResult = await ChatGPT(txtToken.Text, cmbModel.Text, Prompt);

                    row.Cells[4].Value = Prompt;
                    row.Cells[5].Value = PromptResult;

                    string RepID = row.Cells[0].Value.ToString();
                    string RepText = row.Cells[1].Value.ToString();
                    string ICD10 = row.Cells[2].Value.ToString();

                    Save2DB(RepID, ICD10, RepText, Prompt, PromptResult, cmbModel.Text, "");
                }
                return;
            }

            string SupportResult = await ChatGPT(txtToken.Text, cmbModel.Text, txtSupportPrompt.Text);
            SupportMessage = new List<object>
                {
                    new { role = "user", content = txtSupportPrompt.Text },
                    new { role = "assistant", content = SupportResult } // The assistant's response from the previous interaction
            };

            string serializedList = JsonSerializer.Serialize(SupportMessage);


            if (rdbChain.Checked)
            {
                foreach (DataGridViewRow row in dgvReps.Rows)
                {
                    string Prompt = row.Cells[4].Value.ToString();

                    string PromptResult = await ChatGPT(txtToken.Text, cmbModel.Text, Prompt, SupportMessage);

                    row.Cells[5].Value = PromptResult;
                    SupportMessage.Add(new { role = "user", content = Prompt });
                    SupportMessage.Add(new { role = "assistant", content = PromptResult });
                }
            }

            if (rdbBranched.Checked)
            {
                foreach (DataGridViewRow row in dgvReps.Rows)
                {
                    string Prompt = row.Cells[4].Value.ToString();

                    string PromptResult = await ChatGPT(txtToken.Text, cmbModel.Text, Prompt, SupportMessage);

                    row.Cells[5].Value = PromptResult;

                }
            }
            */
        }

        private void txtSupportList_TextChanged(object sender, EventArgs e)
        {

        }

        public static string SaveTextToFile(string textBody, string fileName, string folderPath)
        {
            try
            {
                // Ensure the folder exists
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Combine folder path and file name
                string filePath = Path.Combine(folderPath, fileName);

                // Write the text to the file
                File.WriteAllText(filePath, textBody);

                // Return success message
                return $"Text saved successfully to {filePath}";
            }
            catch (Exception ex)
            {
                // Return the error message
                return $"An error occurred: {ex.Message}";
            }
        }

        public static int CntComma(string commaSeparatedString)
        {
            if (string.IsNullOrWhiteSpace(commaSeparatedString))
            {
                return 0; // Return 0 if the string is null, empty, or only contains whitespace
            }

            // Split the string by commas and count the items
            return commaSeparatedString.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }

        private void btnBatch_Click(object sender, EventArgs e)
        {
            string Prompt = "";
            string Platform = "";
            string sRepID = "";
            string sFile = "";
            string sLine = "";
            string custom_id = "";
            string method = "POST";
            string url = "/v1/chat/completions";
            string model = cmbModel.Text;
            string content1 = "You are a helpful assistant.";
            string role1 = "system";
            string role2 = "user";
            string content2 = "";
            int i = 0;
            string filePath = "D:\\Temp\\";
            string fileName = "";
            string SupportCnt = "";
            string RepsCnt = "";

            SupportCnt = CntComma(txtSupportList.Text).ToString();
            RepsCnt = CntComma(txtPromptList.Text).ToString();

            fileName = cmbICD.Text + "_" + SupportCnt + "_" + RepsCnt + "_" + DateTime.Now.ToString("yyMMddHHmmss") + ".jsonl";
            foreach (DataGridViewRow row in dgvReps.Rows)
            {

                string RepID = row.Cells["RepID"].Value.ToString();
                string RepText = row.Cells["RepText"].Value.ToString();
                string ICD10 = row.Cells["ICD10"].Value.ToString();

                Prompt = row.Cells["GPTPrompt"].Value.ToString();
                sRepID = row.Cells[0].Value.ToString();
                custom_id = cmbICD.Text + "_" + RepID;

                //if (rdbSeparate.Checked && (txtSupportList.Text.Trim() != ""))
                //{
                Prompt = txtSupportPrompt.Text + gNewLine + Prompt;
                //}
                content2 = Prompt.ReplaceLineEndings(". ");
                sLine = "{ \"custom_id\": \"" + custom_id + "\", \"method\": \"" + method + "\", \"url\": \"" + url + "\", \"body\": { \"model\": \"" + model + "\", \"messages\": [{ \"role\": \"" + role1 + "\", \"content\": \"" + content1 + "\"}, { \"role\": \"" + role2 + "\", \"content\": \"" + content2 + "\"}]} }";

                sFile = sFile + sLine + "\r\n";



                //if (rdbChain.Checked && (txtSupportList.Text.Trim() != ""))
                //{
                //    SupportMessage.Add(new { role = "user", content = Prompt });
                //    SupportMessage.Add(new { role = "assistant", content = PromptResult });
                //}

                //if (string.IsNullOrEmpty(PromptResult))
                //{
                //    NoAnswer++;
                //}
                //else
                //{
                //    Answered++;
                //    Save2DB(RepID, ICD10, RepText, txtPromptText.Text, Prompt, PromptResult, cmbModel.Text, SessionID, cmbICD.Text);
                //}

            }
            SaveTextToFile(sFile, fileName, filePath);
        }

        private void cbxTokenize_CheckedChanged(object sender, EventArgs e)
        {
            cmbICD.Text = "";
            btnGO.BackColor = Color.Gray;
            btnGO.Enabled = false;
            //btnPrompt.Enabled = false;
            dgvReps.DataSource = null;
        }
    }

}

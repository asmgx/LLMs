﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace APIApp
{
    internal class ChatGPTClient
    {

        //private const string apiUrl = "https://api-inference.huggingface.co/models/meta-llama/Llama-3.3-70B-Instruct"; // Replace with the actual API endpoint
        //private const string apiUrl = "https://api.openai.com/v1/chat/completions"; // Replace with the actual API endpoint
        //private const string apiUrl = "https://api.groq.com/openai/v1/chat/completions"; // Replace with the actual API endpoint

        public async Task<string> GetChatGPTResponse(string apiUrl, string token, string model, string message, List<object> previousMessages)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

                // Prepare the request data, including previous messages
                var requestData = new
                {
                    model = model,
                    messages = previousMessages.Concat(new[]
                    {
                new
                {
                    role = "user",
                    content = message
                }
            }).ToList()
                };

                // Convert the request data to JSON
                var jsonRequest = JsonConvert.SerializeObject(requestData);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                // Send the request to ChatGPT API
                var response = await httpClient.PostAsync(apiUrl, content);

                // Check if the request was successful
                if (response.IsSuccessStatusCode)
                {
                    // Read and return the content value from the response
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    string Parse = ParseChatGPTResponse(jsonResponse);
                    return Parse;
                }
                else
                {
                    // Handle the error, e.g., log it or throw an exception
                    Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                    return null;
                }
            }
        }

        public async Task<string> GetGeminiResponse(string apiUrl, string token, string model, string message)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                apiUrl = apiUrl + model;
                // Gemini API Key is passed as url parameter.
                string geminiApiUrl = $"{apiUrl}?key={token}";

                object requestData = new
                {
                    contents = new[]
                    {
                    new
                    {
                        parts = new[]
                        {
                            new
                            {
                                text = message
                            }
                        }
                    }
                }
                };

                var jsonRequest = JsonConvert.SerializeObject(requestData);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync(geminiApiUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    return ParseGeminiResponse(jsonResponse);
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                    return null;
                }
            }
        }

        private string ParseGeminiResponse(string jsonResponse)
        {
            try
            {
                dynamic response = JsonConvert.DeserializeObject(jsonResponse);
                if (response?.candidates != null && response.candidates.Count > 0)
                {
                    if (response.candidates[0]?.content?.parts != null && response.candidates[0].content.parts.Count > 0)
                    {
                        return (string)response.candidates[0].content.parts[0].text;
                    }
                }
                return "Gemini API response could not be parsed.";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error parsing Gemini response: {ex.Message}");
                return "Error parsing Gemini API response.";
            }
        }
        /*
        public async Task<string> GetHuggingFaceResponse(string apiUrl, string token, string model, string message)

        {
            var payload = new
            {
                inputs = "What is the biggest animal?"
            };

            var jsonPayload = JsonConvert.SerializeObject(payload);

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", token);

                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                try
                {
                    HttpResponseMessage response = await client.PostAsync(apiUrl, content);

                    // Check if the request was successful
                    if (response.IsSuccessStatusCode)
                    {
                        // Read and return the content value from the response
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        string Parse = ParseChatGPTResponse(jsonResponse);
                        return Parse;
                    }
                    else
                    {
                        // Handle the error, e.g., log it or throw an exception
                        Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                    return null;
                }
            }
        }
        */
        public async Task<string> GetHuggingFaceResponse(string apiUrl, string token, string model, string message)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl); // Set base URL once
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var payload = new
                {
                    inputs = message
                };

                var jsonPayload = JsonConvert.SerializeObject(payload);
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                try
                {
                    var response = await client.PostAsync($"/models/{model}", content); // Append model to base URL
                    response.EnsureSuccessStatusCode();

                    var responseContent = await response.Content.ReadAsStringAsync();

                    // Attempt to deserialize to a more general object first.
                    // This handles cases where the API returns a simple string or a more complex JSON structure.
                    try
                    {
                        // Try deserializing to a string first (common case)
                        return JsonConvert.DeserializeObject<string>(responseContent);
                    }
                    catch (JsonReaderException)
                    {
                        // If that fails, try deserializing to a JObject
                        var jsonObject = Newtonsoft.Json.Linq.JObject.Parse(responseContent);
                        if (jsonObject["generated_text"] != null)
                            return jsonObject["generated_text"].ToString();
                        else
                            return responseContent;//return the whole json string
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error deserializing response: {ex.Message}");
                        return responseContent;
                    }

                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine($"HTTP request error: {ex.Message}");
                    if (ex.InnerException != null)
                    {
                        Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"General error: {ex.Message}");
                    return null;
                }
            }
        }

        //public async Task<string> GetGeminiResponse(string apiUrl, string token, string model, string message)//, bool isHuggingFace = true)
        //{
        //    using (HttpClient httpClient = new HttpClient())
        //    {
        //        //httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

        //        object requestData;

        //            requestData = new
        //            {
        //                model = model,
        //                messages = new[]
        //                {
        //            new
        //            {
        //                role = "system",
        //                content = "You are a helpful assistant."
        //            },
        //            new
        //            {
        //                role = "user",
        //                content = message
        //            }
        //        }
        //            };
                

        //        var jsonRequest = JsonConvert.SerializeObject(requestData);
        //        var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

        //        var response = await httpClient.PostAsync(apiUrl, content);

        //        if (response.IsSuccessStatusCode)
        //        {
        //            string jsonResponse = await response.Content.ReadAsStringAsync();
        //            string Parse = ParseChatGPTResponse(jsonResponse);
        //            return Parse;
        //        }
        //        else
        //        {
        //            Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
        //            return null;
        //        }
        //    }
        //}

        public async Task<string> GetChatGPTResponse(string apiUrl, string token, string model, string message)//, bool isHuggingFace = true)
        {
            bool isHuggingFace=false;
            if (token.StartsWith("hf_")) { isHuggingFace = true; }
            using (HttpClient httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

                object requestData;

                if (isHuggingFace)
                {
                    requestData = new
                    {
                        inputs = message
                    };
                }
                else
                {
                    requestData = new
                    {
                        model = model,
                        messages = new[]
                        {
                    new
                    {
                        role = "system",
                        content = "You are a helpful assistant."
                    },
                    new
                    {
                        role = "user",
                        content = message
                    }
                }
                    };
                }

                var jsonRequest = JsonConvert.SerializeObject(requestData);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync(apiUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    string Parse = ParseChatGPTResponse(jsonResponse);
                    return Parse;
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                    return null;
                }
            }
        }


        // public async Task<string> GetChatGPTResponse(string apiUrl, string token, string model, string message)
        // {
        //     using (HttpClient httpClient = new HttpClient())
        //     {
        //         httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

        //         // Prepare the request data
        //         var requestData = new
        //         {
        //             model = model,
        //             messages = new[]
        //             {
        //             new
        //             {
        //                 role = "system",
        //                 content = "You are a helpful assistant."
        //             },
        //             new
        //             {
        //                 role = "user",
        //                 content = message
        //             }
        //         }
        //         };

        //         // Convert the request data to JSON
        //         var jsonRequest = JsonConvert.SerializeObject(requestData);
        //         var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

        //         // Send the request to ChatGPT API
        //         var response = await httpClient.PostAsync(apiUrl, content);

        //         // Check if the request was successful
        //         if (response.IsSuccessStatusCode)
        //         {
        //             // Read and return the content value from the response
        //             string jsonResponse = await response.Content.ReadAsStringAsync();
        //             string Parse = ParseChatGPTResponse(jsonResponse);
        //             return Parse;
        //         }
        //         else
        //         {
        //             // Handle the error, e.g., log it or throw an exception
        //             Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
        //             return null;
        //         }
        //     }
        // }

        private string ParseChatGPTResponse(string jsonResponse)
        {
            try
            {
                // Parse the JSON string
                JObject jsonObject = JObject.Parse(jsonResponse);

                // Extract the "content" value from the message within the first choice
                string contentValue = jsonObject["choices"][0]["message"]["content"].ToString();

                return contentValue;
            }
            catch (Exception ex)
            {
                return "ERROR: Error parsing JSON response: " + ex.Message;
            }

        }

    }
}

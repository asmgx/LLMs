using System.Text;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Net.Security;
using System.Reflection.Metadata;
using System.Text.RegularExpressions;

namespace APIApp
{
    public partial class frmChatGPT : Form
    {
        public frmChatGPT()
        {
            InitializeComponent();
        }
        private string gNewLine = Environment.NewLine;

        //public async Task<string> GetChatGPTResponse(string token, string model, string message)
        //{
        //    using (HttpClient httpClient = new HttpClient())
        //    {
        //        httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token}");

        //        // Prepare the request data
        //        var requestData = new
        //        {
        //            model = model,
        //            messages = new[]
        //            {
        //            new
        //            {
        //                role = "system",
        //                content = "You are a helpful assistant."
        //            },
        //            new
        //            {
        //                role = "user",
        //                content = message
        //            }
        //        }
        //        };

        //        // Convert the request data to JSON
        //        var jsonRequest = Newtonsoft.Json.JsonConvert.SerializeObject(requestData);
        //        var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

        //        // Send the request to ChatGPT API
        //        var response = await httpClient.PostAsync(apiUrl, content);

        //        // Check if the request was successful
        //        if (response.IsSuccessStatusCode)
        //        {
        //            // Read and return the response content
        //            return await response.Content.ReadAsStringAsync();
        //        }
        //        else
        //        {
        //            // Handle the error, e.g., log it or throw an exception
        //            Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
        //            return null;
        //        }
        //    }
        //}


        static async Task<string> ChatGPT(string apiUrl, string token, string model, string message, string Platform)
        {
            //string token = "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"; // Replace with your actual API key
            //string model = "gpt-3.5-turbo"; // Replace with the desired model
            //string message = "Translate the following English text to French: ";
            string result = "";
            ChatGPTClient chatGPTClient = new ChatGPTClient();
            if (Platform=="HF")
            { 
             result = await chatGPTClient.GetHuggingFaceResponse(apiUrl, token, model, message);
            }
            else if (Platform=="Gemini")
            {
                result = await chatGPTClient.GetGeminiResponse(apiUrl, token, model, message);
            }
            else
            {
             result = await chatGPTClient.GetChatGPTResponse(apiUrl, token, model, message);

            }

            // Process and use the result as needed
            //Console.WriteLine(result);
            return result;
        }

        private async void btnCall_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            SqlConnection myConn = new SqlConnection("Data Source=*****;Initial Catalog=LLM;User ID=****;Password=******");
            myConn.Open();
            SqlCommand myCmd = new SqlCommand("phdGPTResultInsert", myConn);
            myCmd.CommandType = CommandType.StoredProcedure;
            myCmd.Parameters.Add(new SqlParameter("@RepID", 0));
            myCmd.Parameters.Add(new SqlParameter("@ICD10", ""));
            myCmd.Parameters.Add(new SqlParameter("@RepText", ""));
            myCmd.Parameters.Add(new SqlParameter("@Prompt", ""));
            myCmd.Parameters.Add(new SqlParameter("@Template", ""));
            myCmd.Parameters.Add(new SqlParameter("@Answer", ""));
            myCmd.Parameters.Add(new SqlParameter("@Model", ""));


            foreach (DataGridViewRow row in dgvReps.Rows)
            {
                System.Threading.Thread.Sleep(1000);
                string RepText = row.Cells[1].Value.ToString();

                string RepID = row.Cells[0].Value.ToString();
                string ICD10Code = row.Cells[2].Value.ToString();
                string ICD10Name = "";
                if (ICD10Code == "A41") { ICD10Name = "Sepsis"; }
                if (ICD10Code == "I21") { ICD10Name = "Myocardial infarction"; }
                if (ICD10Code == "Z51") { ICD10Name = "Encounter for other aftercare and medical care"; }
                if (ICD10Code == "I25") { ICD10Name = "Chronic ischaemic heart disease"; }
                if (ICD10Code == "I13") { ICD10Name = "Hypertensive heart and renal disease"; }


                string token = txtToken.Text;
                string model = cmbModel.Text;
                string template = txtPrompt.Text;
                string message = txtPrompt.Text.Replace("[RepText]", RepText);
                message = message.Replace("[ICD10Code]", ICD10Code);
                message = message.Replace("[ICD10Name]", ICD10Name);

                string result = "";//await ChatGPT(token, model, message);
                if (result == null) { result = ""; }

                row.Cells[3].Value = result;

                myCmd.Parameters["@RepID"].Value = RepID;
                myCmd.Parameters["@ICD10"].Value = ICD10Code;
                myCmd.Parameters["@RepText"].Value = RepText;
                myCmd.Parameters["@Prompt"].Value = message;
                myCmd.Parameters["@Template"].Value = template;
                myCmd.Parameters["@Answer"].Value = result;
                myCmd.Parameters["@Model"].Value = model;
                myCmd.ExecuteNonQuery();


                txtResults.Text += result + gNewLine + gNewLine + "--------------------------------------------" + gNewLine + gNewLine;
            }

            MessageBox.Show("Done");
        }

        private void btnReps_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            SqlConnection myConn = new SqlConnection("Data Source=*****;Initial Catalog=LLM;User ID=****;Password=******");
            myConn.Open();
            SqlCommand myCmd = new SqlCommand("phdGPTReps", myConn);
            myCmd.CommandType = CommandType.StoredProcedure;
            txtReps.Text = Regex.Replace(txtReps.Text, @"\s+", string.Empty);

            myCmd.Parameters.Add("@Reps", SqlDbType.VarChar).Value = txtReps.Text;

            SqlDataAdapter da = new SqlDataAdapter(myCmd);
            da.Fill(dt);
            dgvReps.DataSource = dt;

            // Set your desired AutoSize Mode:
            dgvReps.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgvReps.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvReps.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            // Now that DataGridView has calculated it's Widths; we can now store each column Width values.
            for (int i = 0; i <= dgvReps.Columns.Count - 1; i++)
            {
                // Store Auto Sized Widths:
                int colw = dgvReps.Columns[i].Width;

                // Remove AutoSizing:
                dgvReps.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;

                // Set Width to calculated AutoSize value:
                dgvReps.Columns[i].Width = colw;
            }

        }
    }
}
﻿namespace APIApp
{
    partial class frmGPTConv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGPTConv));
            btnGO = new Button();
            label9 = new Label();
            txtSupportPrompt = new TextBox();
            label8 = new Label();
            txtResults = new TextBox();
            label7 = new Label();
            txtSubSupportText = new TextBox();
            dgvReps = new DataGridView();
            label5 = new Label();
            cmbModel = new ComboBox();
            label6 = new Label();
            textBox5 = new TextBox();
            rdbBranched = new RadioButton();
            rdbChain = new RadioButton();
            rdbSeparate = new RadioButton();
            btnPrompt = new Button();
            label3 = new Label();
            txtPromptList = new TextBox();
            label4 = new Label();
            txtPromptText = new TextBox();
            btnSupport = new Button();
            label2 = new Label();
            txtSupportList = new TextBox();
            label1 = new Label();
            txtSupportText = new TextBox();
            cmbSession = new ComboBox();
            label10 = new Label();
            lblSessionID = new Label();
            cmbICD = new ComboBox();
            label11 = new Label();
            label12 = new Label();
            cmbWait = new ComboBox();
            cbxToken = new ComboBox();
            cbxAPI = new ComboBox();
            label13 = new Label();
            btnBatch = new Button();
            cbxTokenize = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)dgvReps).BeginInit();
            SuspendLayout();
            // 
            // btnGO
            // 
            btnGO.BackColor = SystemColors.Control;
            btnGO.Enabled = false;
            btnGO.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            btnGO.Location = new Point(635, 145);
            btnGO.Name = "btnGO";
            btnGO.Size = new Size(171, 67);
            btnGO.TabIndex = 51;
            btnGO.Text = "GO";
            btnGO.UseVisualStyleBackColor = false;
            btnGO.Click += btnGO_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(11, 771);
            label9.Name = "label9";
            label9.Size = new Size(142, 25);
            label9.TabIndex = 50;
            label9.Text = "Support Prompt";
            // 
            // txtSupportPrompt
            // 
            txtSupportPrompt.Location = new Point(11, 798);
            txtSupportPrompt.Margin = new Padding(2);
            txtSupportPrompt.Multiline = true;
            txtSupportPrompt.Name = "txtSupportPrompt";
            txtSupportPrompt.ReadOnly = true;
            txtSupportPrompt.ScrollBars = ScrollBars.Both;
            txtSupportPrompt.Size = new Size(583, 179);
            txtSupportPrompt.TabIndex = 49;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(1449, 7);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(67, 25);
            label8.TabIndex = 48;
            label8.Text = "Results";
            // 
            // txtResults
            // 
            txtResults.Location = new Point(1449, 34);
            txtResults.Margin = new Padding(2);
            txtResults.Multiline = true;
            txtResults.Name = "txtResults";
            txtResults.ReadOnly = true;
            txtResults.ScrollBars = ScrollBars.Both;
            txtResults.Size = new Size(424, 943);
            txtResults.TabIndex = 47;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(54, 255);
            label7.Name = "label7";
            label7.Size = new Size(78, 25);
            label7.TabIndex = 46;
            label7.Text = "Sub Text";
            // 
            // txtSubSupportText
            // 
            txtSubSupportText.Location = new Point(138, 252);
            txtSubSupportText.Name = "txtSubSupportText";
            txtSubSupportText.Size = new Size(456, 31);
            txtSubSupportText.TabIndex = 45;
            txtSubSupportText.Text = "- Discharge Summary: [RepText]. \r\n\tICD-10 Code: [ICD10YN], [ICD10Code] is [ICD10Label]present\r\n";
            // 
            // dgvReps
            // 
            dgvReps.AllowUserToAddRows = false;
            dgvReps.AllowUserToDeleteRows = false;
            dgvReps.AllowUserToOrderColumns = true;
            dgvReps.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvReps.Location = new Point(12, 514);
            dgvReps.Margin = new Padding(2);
            dgvReps.Name = "dgvReps";
            dgvReps.ReadOnly = true;
            dgvReps.RowHeadersWidth = 82;
            dgvReps.RowTemplate.Height = 41;
            dgvReps.Size = new Size(1413, 246);
            dgvReps.TabIndex = 44;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(843, 7);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(63, 25);
            label5.TabIndex = 43;
            label5.Text = "Model";
            // 
            // cmbModel
            // 
            cmbModel.FormattingEnabled = true;
            cmbModel.Items.AddRange(new object[] { ">>>OpenAI", "-----------------------------", "gpt-4.5-preview", "o1", "o1-mini", "o3-mini", "gpt-4o", "gpt-4o-mini", "gpt-4o-mini", "gpt-4-0125-preview", "gpt-4-turbo-preview", "gpt-4-1106-preview", "gpt-4-vision-preview", "gpt-4-1106-vision-preview", "gpt-4", "gpt-4-0613", "gpt-4-32k", "gpt-4-32k-0613", "gpt-3.5-turbo", "", ">>>Groq", "-----------------------------", "meta-llama/llama-4-maverick-17b-128e-instruct", "meta-llama/llama-4-scout-17b-16e-instruct", "llama-3.3-70b-versatile", "llama3-70b-8192", "llama-3.1-70b-versatile", "llama-3.2-90b-text-preview", "deepseek-r1-distill-llama-70b", "deepseek-r1-distill-llama-70b-specdec", "qwen-qwq-32b", "qwen-2.5-32b", "", ">>>HuggingFace", "-----------------------------", "meta-llama/Llama-3.3-70B-Instruct", "", ">>>DeepSeek", "-----------------------------", "deepseek-chat", "deepseek-reasoner", "", ">>>Gemini", "-----------------------------", "gemini-2.5-pro-preview-03-25:generateContent", "gemini-2.0-flash:generateContent", "gemini-2.0-flash-thinking-exp-01-21:generateContent", "gemini-1.5-pro-002:generateContent", "gemini-1.5-flash-002:generateContent", "gemma-02-27b-it:generateContent", "gemini-2.0-flash-lite:generateContent", "", ">>>Together", "-----------------", "deepseek-ai/DeepSeek-R1" });
            cmbModel.Location = new Point(843, 35);
            cmbModel.Margin = new Padding(2);
            cmbModel.Name = "cmbModel";
            cmbModel.Size = new Size(262, 33);
            cmbModel.TabIndex = 42;
            cmbModel.Text = "qwen-2.5-32b";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 98);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(58, 25);
            label6.TabIndex = 41;
            label6.Text = "Token";
            // 
            // textBox5
            // 
            textBox5.BackColor = SystemColors.ButtonFace;
            textBox5.BorderStyle = BorderStyle.None;
            textBox5.Enabled = false;
            textBox5.Location = new Point(599, 771);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(808, 206);
            textBox5.TabIndex = 39;
            textBox5.Text = resources.GetString("textBox5.Text");
            // 
            // rdbBranched
            // 
            rdbBranched.AutoSize = true;
            rdbBranched.Location = new Point(635, 456);
            rdbBranched.Name = "rdbBranched";
            rdbBranched.Size = new Size(152, 29);
            rdbBranched.TabIndex = 38;
            rdbBranched.Text = "Branched Lead";
            rdbBranched.UseVisualStyleBackColor = true;
            // 
            // rdbChain
            // 
            rdbChain.AutoSize = true;
            rdbChain.Location = new Point(635, 421);
            rdbChain.Name = "rdbChain";
            rdbChain.Size = new Size(81, 29);
            rdbChain.TabIndex = 37;
            rdbChain.Text = "Chain";
            rdbChain.UseVisualStyleBackColor = true;
            // 
            // rdbSeparate
            // 
            rdbSeparate.AutoSize = true;
            rdbSeparate.Checked = true;
            rdbSeparate.Location = new Point(635, 386);
            rdbSeparate.Name = "rdbSeparate";
            rdbSeparate.Size = new Size(106, 29);
            rdbSeparate.TabIndex = 36;
            rdbSeparate.TabStop = true;
            rdbSeparate.Text = "Separate";
            rdbSeparate.UseVisualStyleBackColor = true;
            // 
            // btnPrompt
            // 
            btnPrompt.Location = new Point(1312, 301);
            btnPrompt.Name = "btnPrompt";
            btnPrompt.Size = new Size(112, 34);
            btnPrompt.TabIndex = 35;
            btnPrompt.Text = "Prompt";
            btnPrompt.UseVisualStyleBackColor = true;
            btnPrompt.Click += btnPrompt_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(847, 314);
            label3.Name = "label3";
            label3.Size = new Size(103, 25);
            label3.TabIndex = 34;
            label3.Text = "Prompt List";
            // 
            // txtPromptList
            // 
            txtPromptList.Location = new Point(843, 342);
            txtPromptList.Multiline = true;
            txtPromptList.Name = "txtPromptList";
            txtPromptList.Size = new Size(582, 167);
            txtPromptList.TabIndex = 33;
            txtPromptList.Text = "2,3,5,6,8,9,11,12";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(847, 98);
            label4.Name = "label4";
            label4.Size = new Size(107, 25);
            label4.TabIndex = 32;
            label4.Text = "Prompt Text";
            // 
            // txtPromptText
            // 
            txtPromptText.Location = new Point(842, 126);
            txtPromptText.Multiline = true;
            txtPromptText.Name = "txtPromptText";
            txtPromptText.Size = new Size(582, 111);
            txtPromptText.TabIndex = 31;
            txtPromptText.Text = resources.GetString("txtPromptText.Text");
            // 
            // btnSupport
            // 
            btnSupport.Location = new Point(482, 302);
            btnSupport.Name = "btnSupport";
            btnSupport.Size = new Size(112, 34);
            btnSupport.TabIndex = 30;
            btnSupport.Text = "Support";
            btnSupport.UseVisualStyleBackColor = true;
            btnSupport.Click += btnSupport_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(11, 314);
            label2.Name = "label2";
            label2.Size = new Size(108, 25);
            label2.TabIndex = 29;
            label2.Text = "Support List";
            // 
            // txtSupportList
            // 
            txtSupportList.Location = new Point(12, 342);
            txtSupportList.Multiline = true;
            txtSupportList.Name = "txtSupportList";
            txtSupportList.Size = new Size(582, 167);
            txtSupportList.TabIndex = 28;
            txtSupportList.TextChanged += txtSupportList_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(17, 187);
            label1.Name = "label1";
            label1.Size = new Size(112, 25);
            label1.TabIndex = 27;
            label1.Text = "Support Text";
            // 
            // txtSupportText
            // 
            txtSupportText.Location = new Point(12, 215);
            txtSupportText.Name = "txtSupportText";
            txtSupportText.Size = new Size(582, 31);
            txtSupportText.TabIndex = 26;
            txtSupportText.Text = resources.GetString("txtSupportText.Text");
            // 
            // cmbSession
            // 
            cmbSession.FormattingEnabled = true;
            cmbSession.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99" });
            cmbSession.Location = new Point(294, 302);
            cmbSession.Name = "cmbSession";
            cmbSession.Size = new Size(182, 33);
            cmbSession.TabIndex = 52;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(599, 9);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(95, 25);
            label10.TabIndex = 53;
            label10.Text = "Session ID";
            // 
            // lblSessionID
            // 
            lblSessionID.AutoSize = true;
            lblSessionID.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point);
            lblSessionID.Location = new Point(635, 41);
            lblSessionID.Margin = new Padding(2, 0, 2, 0);
            lblSessionID.Name = "lblSessionID";
            lblSessionID.Size = new Size(83, 96);
            lblSessionID.TabIndex = 54;
            lblSessionID.Text = "#";
            // 
            // cmbICD
            // 
            cmbICD.FormattingEnabled = true;
            cmbICD.Items.AddRange(new object[] { "A41", "E78", "I10", "I13", "I21", "I25", "Y92", "Z51", "Z79", "Z87" });
            cmbICD.Location = new Point(635, 342);
            cmbICD.Name = "cmbICD";
            cmbICD.Size = new Size(182, 33);
            cmbICD.TabIndex = 55;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(635, 314);
            label11.Name = "label11";
            label11.Size = new Size(61, 25);
            label11.TabIndex = 56;
            label11.Text = "ICD10";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(1132, 6);
            label12.Margin = new Padding(2, 0, 2, 0);
            label12.Name = "label12";
            label12.Size = new Size(47, 25);
            label12.TabIndex = 58;
            label12.Text = "Wait";
            // 
            // cmbWait
            // 
            cmbWait.FormattingEnabled = true;
            cmbWait.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "15", "20", "25", "30", "40", "50", "60", "90", "120", "180", "240", "300" });
            cmbWait.Location = new Point(1132, 34);
            cmbWait.Margin = new Padding(2);
            cmbWait.Name = "cmbWait";
            cmbWait.Size = new Size(262, 33);
            cmbWait.TabIndex = 57;
            cmbWait.Text = "0";
            // 
            // cbxToken
            // 
            cbxToken.FormattingEnabled = true;
            cbxToken.Items.AddRange(new object[] { ">>>>ChatGPT", "-----------------", "sk-proj-rbX*************************************", "", ">>>>Groq", "-----------------", "gsk_kB******************************************", "", ">>>>HuggingFace", "-----------------", "hf_so*******************************************", "", ">>>>DeepSeek", "-----------------", "sk-61d*********************************************", "", ">>>>Gemini", "-----------------", "AIza************************************************", "", ">>>>Together", "-----------------", "56c2************************************************" });
            cbxToken.Location = new Point(12, 126);
            cbxToken.Name = "cbxToken";
            cbxToken.Size = new Size(583, 33);
            cbxToken.TabIndex = 59;
            cbxToken.Text = "gsk_kBf**********************************";
            // 
            // cbxAPI
            // 
            cbxAPI.FormattingEnabled = true;
            cbxAPI.Items.AddRange(new object[] { "https://api.openai.com/v1/chat/completions", "https://api.groq.com/openai/v1/chat/completions", "https://api-inference.huggingface.co/models/meta-llama/Llama-3.3-70B-Instruct", "https://api.deepseek.com/v1/chat/completions", "https://generativelanguage.googleapis.com/v1beta/models/", "https://api.together.xyz/v1/chat/completions" });
            cbxAPI.Location = new Point(11, 41);
            cbxAPI.Name = "cbxAPI";
            cbxAPI.Size = new Size(583, 33);
            cbxAPI.TabIndex = 61;
            cbxAPI.Text = "https://api.groq.com/openai/v1/chat/completions";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(11, 9);
            label13.Margin = new Padding(2, 0, 2, 0);
            label13.Name = "label13";
            label13.Size = new Size(39, 25);
            label13.TabIndex = 60;
            label13.Text = "API";
            // 
            // btnBatch
            // 
            btnBatch.BackColor = SystemColors.Control;
            btnBatch.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            btnBatch.Location = new Point(635, 218);
            btnBatch.Name = "btnBatch";
            btnBatch.Size = new Size(171, 51);
            btnBatch.TabIndex = 62;
            btnBatch.Text = "Batch";
            btnBatch.UseVisualStyleBackColor = false;
            btnBatch.Click += btnBatch_Click;
            // 
            // cbxTokenize
            // 
            cbxTokenize.AutoSize = true;
            cbxTokenize.Checked = true;
            cbxTokenize.CheckState = CheckState.Checked;
            cbxTokenize.Location = new Point(635, 282);
            cbxTokenize.Name = "cbxTokenize";
            cbxTokenize.Size = new Size(116, 29);
            cbxTokenize.TabIndex = 63;
            cbxTokenize.Text = "Tokenized";
            cbxTokenize.UseVisualStyleBackColor = true;
            cbxTokenize.CheckedChanged += cbxTokenize_CheckedChanged;
            // 
            // frmGPTConv
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1882, 988);
            Controls.Add(cbxTokenize);
            Controls.Add(btnBatch);
            Controls.Add(cbxAPI);
            Controls.Add(label13);
            Controls.Add(cbxToken);
            Controls.Add(label12);
            Controls.Add(cmbWait);
            Controls.Add(label11);
            Controls.Add(cmbICD);
            Controls.Add(lblSessionID);
            Controls.Add(label10);
            Controls.Add(cmbSession);
            Controls.Add(btnGO);
            Controls.Add(label9);
            Controls.Add(txtSupportPrompt);
            Controls.Add(label8);
            Controls.Add(txtResults);
            Controls.Add(label7);
            Controls.Add(txtSubSupportText);
            Controls.Add(dgvReps);
            Controls.Add(label5);
            Controls.Add(cmbModel);
            Controls.Add(label6);
            Controls.Add(textBox5);
            Controls.Add(rdbBranched);
            Controls.Add(rdbChain);
            Controls.Add(rdbSeparate);
            Controls.Add(btnPrompt);
            Controls.Add(label3);
            Controls.Add(txtPromptList);
            Controls.Add(label4);
            Controls.Add(txtPromptText);
            Controls.Add(btnSupport);
            Controls.Add(label2);
            Controls.Add(txtSupportList);
            Controls.Add(label1);
            Controls.Add(txtSupportText);
            Name = "frmGPTConv";
            Text = "frmGPTConv";
            ((System.ComponentModel.ISupportInitialize)dgvReps).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnGO;
        private Label label9;
        private TextBox txtSupportPrompt;
        private Label label8;
        private TextBox txtResults;
        private Label label7;
        private TextBox txtSubSupportText;
        private DataGridView dgvReps;
        private Label label5;
        private ComboBox cmbModel;
        private Label label6;
        private TextBox txtToken;
        private TextBox textBox5;
        private RadioButton rdbBranched;
        private RadioButton rdbChain;
        private RadioButton rdbSeparate;
        private Button btnPrompt;
        private Label label3;
        private TextBox txtPromptList;
        private Label label4;
        private TextBox txtPromptText;
        private Button btnSupport;
        private Label label2;
        private TextBox txtSupportList;
        private Label label1;
        private TextBox txtSupportText;
        private ComboBox cmbSession;
        private Label label10;
        private Label lblSessionID;
        private ComboBox cmbICD;
        private Label label11;
        private Label label12;
        private ComboBox cmbWait;
        private ComboBox cbxToken;
        private ComboBox cbxAPI;
        private Label label13;
        private Button btnBatch;
        private CheckBox cbxTokenize;
    }
}
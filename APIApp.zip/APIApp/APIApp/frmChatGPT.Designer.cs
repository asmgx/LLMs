﻿namespace APIApp
{
    partial class frmChatGPT
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChatGPT));
            txtToken = new TextBox();
            label1 = new Label();
            txtPrompt = new TextBox();
            label2 = new Label();
            cmbModel = new ComboBox();
            label3 = new Label();
            txtResults = new TextBox();
            label4 = new Label();
            btnCall = new Button();
            label5 = new Label();
            txtReps = new TextBox();
            dgvReps = new DataGridView();
            srcReps = new BindingSource(components);
            btnReps = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvReps).BeginInit();
            ((System.ComponentModel.ISupportInitialize)srcReps).BeginInit();
            SuspendLayout();
            // 
            // txtToken
            // 
            txtToken.Location = new Point(18, 55);
            txtToken.Margin = new Padding(2);
            txtToken.Name = "txtToken";
            txtToken.Size = new Size(262, 31);
            txtToken.TabIndex = 0;
            txtToken.Text = "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";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 27);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(58, 25);
            label1.TabIndex = 1;
            label1.Text = "Token";
            // 
            // txtPrompt
            // 
            txtPrompt.Location = new Point(18, 138);
            txtPrompt.Margin = new Padding(2);
            txtPrompt.Name = "txtPrompt";
            txtPrompt.ScrollBars = ScrollBars.Both;
            txtPrompt.Size = new Size(856, 31);
            txtPrompt.TabIndex = 2;
            txtPrompt.Text = "In the role of a clinical coder, would you categorize this discharge summary as ICD10 = [ICD10Code] or not? answer with yes or no, then explain your answer \"[RepText]\"?";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 111);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(72, 25);
            label2.TabIndex = 3;
            label2.Text = "Prompt";
            // 
            // cmbModel
            // 
            cmbModel.FormattingEnabled = true;
            cmbModel.Items.AddRange(new object[] { "gpt-4-0125-preview", "gpt-4-turbo-preview", "gpt-4-1106-preview", "gpt-4-vision-preview", "gpt-4-1106-vision-preview", "gpt-4", "gpt-4-0613", "gpt-4-32k", "gpt-4-32k-0613", "gpt-3.5-turbo" });
            cmbModel.Location = new Point(611, 55);
            cmbModel.Margin = new Padding(2);
            cmbModel.Name = "cmbModel";
            cmbModel.Size = new Size(262, 33);
            cmbModel.TabIndex = 4;
            cmbModel.Text = "gpt-3.5-turbo";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(611, 27);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(63, 25);
            label3.TabIndex = 5;
            label3.Text = "Model";
            // 
            // txtResults
            // 
            txtResults.Location = new Point(27, 498);
            txtResults.Margin = new Padding(2);
            txtResults.Multiline = true;
            txtResults.Name = "txtResults";
            txtResults.ReadOnly = true;
            txtResults.ScrollBars = ScrollBars.Both;
            txtResults.Size = new Size(856, 147);
            txtResults.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 470);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(67, 25);
            label4.TabIndex = 7;
            label4.Text = "Results";
            // 
            // btnCall
            // 
            btnCall.Location = new Point(402, 55);
            btnCall.Margin = new Padding(2);
            btnCall.Name = "btnCall";
            btnCall.Size = new Size(115, 36);
            btnCall.TabIndex = 8;
            btnCall.Text = "Call";
            btnCall.UseVisualStyleBackColor = true;
            btnCall.Click += btnCall_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(18, 197);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(73, 25);
            label5.TabIndex = 9;
            label5.Text = "Reports";
            // 
            // txtReps
            // 
            txtReps.Location = new Point(18, 224);
            txtReps.Margin = new Padding(2);
            txtReps.Multiline = true;
            txtReps.Name = "txtReps";
            txtReps.ScrollBars = ScrollBars.Both;
            txtReps.Size = new Size(739, 82);
            txtReps.TabIndex = 10;
            txtReps.Text = resources.GetString("txtReps.Text");
            // 
            // dgvReps
            // 
            dgvReps.AllowUserToAddRows = false;
            dgvReps.AllowUserToDeleteRows = false;
            dgvReps.AllowUserToOrderColumns = true;
            dgvReps.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvReps.Location = new Point(18, 318);
            dgvReps.Margin = new Padding(2);
            dgvReps.Name = "dgvReps";
            dgvReps.ReadOnly = true;
            dgvReps.RowHeadersWidth = 82;
            dgvReps.RowTemplate.Height = 41;
            dgvReps.Size = new Size(855, 140);
            dgvReps.TabIndex = 11;
            // 
            // btnReps
            // 
            btnReps.Location = new Point(760, 221);
            btnReps.Margin = new Padding(2);
            btnReps.Name = "btnReps";
            btnReps.Size = new Size(115, 84);
            btnReps.TabIndex = 12;
            btnReps.Text = "Reps";
            btnReps.UseVisualStyleBackColor = true;
            btnReps.Click += btnReps_Click;
            // 
            // frmChatGPT
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(905, 691);
            Controls.Add(btnReps);
            Controls.Add(dgvReps);
            Controls.Add(txtReps);
            Controls.Add(label5);
            Controls.Add(btnCall);
            Controls.Add(label4);
            Controls.Add(txtResults);
            Controls.Add(label3);
            Controls.Add(cmbModel);
            Controls.Add(label2);
            Controls.Add(txtPrompt);
            Controls.Add(label1);
            Controls.Add(txtToken);
            Margin = new Padding(2);
            Name = "frmChatGPT";
            Text = "ChatGPT";
            ((System.ComponentModel.ISupportInitialize)dgvReps).EndInit();
            ((System.ComponentModel.ISupportInitialize)srcReps).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtToken;
        private Label label1;
        private TextBox txtPrompt;
        private Label label2;
        private ComboBox cmbModel;
        private Label label3;
        private TextBox txtResults;
        private Label label4;
        private Button btnCall;
        private Label label5;
        private TextBox txtReps;
        private DataGridView dgvReps;
        private BindingSource srcReps;
        private Button btnReps;
    }
}